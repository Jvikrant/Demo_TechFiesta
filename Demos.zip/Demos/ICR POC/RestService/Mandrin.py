# -*- coding: utf-8 -*-
"""
Created on Wed Apr 25 11:32:01 2018

@author: jdhruwa
"""

#plotting image
from matplotlib.patches import Polygon
from PIL import Image
from io import BytesIO
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import requests

def plot_image(polygons,image_url,input_flag):
    plt.figure(num=None, figsize=(8, 6), dpi=80, facecolor='w', edgecolor='k')
    if input_flag:
        image  = Image.open(BytesIO(requests.get(image_url).content))
    else:
        image = mpimg.imread(image_url)
        
    ax= plt.imshow(image)
    
    text2=""
    for polygon in polygons:
        vertices = [(polygon[0][i], polygon[0][i+1]) for i in range(0,len(polygon[0]),2)]
        text     =polygon[1]
        text2    +="\n"+polygon[1]
        patch    = Polygon(vertices, closed=True,fill=False, linewidth=2, color='y')
        ax.axes.add_patch(patch)
        plt.text(vertices[0][0], vertices[0][1], text, fontsize=20, va="top",color='r')
    
    #plt.title(text, size="x-large", y=-0.1)
    
    print(text2)
    plt.axis("off")
    
    return text2
    
    
