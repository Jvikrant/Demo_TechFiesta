1. Check following libraries
	python
	flask
	requests
	matploltlib
	pillow/pil
	

2. Run server.py from cmd

3. Check URL in browser
	localhost:5000/upload

Done!!!


API Keys:
https://westcentralus.api.cognitive.microsoft.com/vision/v1.0

https://westcentralus.api.cognitive.microsoft.com/vision/v2.0

Key 1: 1888e03e35ed4bbaa1bb1afffdc52ce7

Key 2: c4008e08d16549fea514a0af70f2b0ce 



